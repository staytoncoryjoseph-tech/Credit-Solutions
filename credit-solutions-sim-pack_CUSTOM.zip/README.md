# Credit Solutions — Simulators Pack (DTI, Score Simulator, Pricing Marker)

This bundle is **wired to your pricing model** in `model.config.json`. Edit that one file and the UI updates.

## What’s inside
- `index.html` — demo page with three widgets and your colors (navy/gold/white).
- `sim.css` — styles.
- `sim.js` — logic for:
  1) **Debt-to-Income (DTI) Calculator**
  2) **Credit Score Simulator** (based on your `scoreModelWeights`)
  3) **Credit Repair Pricing Marker** (based on your `scoreBands`, setup fees, etc.)
- `model.config.json` — **the only file you need to edit** to change pricing/weights.

## Quick start
1. Unzip and open `index.html` in a browser.
2. To embed on your site:
   ```html
   <link rel="stylesheet" href="/assets/sim.css">
   <script src="/assets/model.config.json" type="application/json" id="credit-model"></script>
   <script defer src="/assets/sim.js"></script>
   ```
   Then add any of these anchors where you want widgets:
   ```html
   <div id="dti-widget"></div>
   <div id="score-sim-widget"></div>
   <div id="pricing-marker-widget"></div>
   <script>
     CreditSolutions.mountAll(); // mounts all three if the anchors exist
   </script>
   ```

## Editing your pricing model
Open `model.config.json` and adjust:
- `scoreBands[].monthlyBase` — base monthly by score band
- `monthlyPerDerogatory` — $/month per negative item
- `setupFee.base` and `setupFee.perDerogatory`
- `rushUpliftPct` — percent uplift for rush service
- `clampMonthly.min/max` — marker scale and clamp
- `addOns` — names & prices
- `scoreModelWeights` — how the simulator translates inputs into a score

> Tip: After edits, refresh the page. The script reads the JSON at runtime.

## Disclaimers
- Estimates only; **no guarantees** of specific outcomes or deletions.
- For compliance, include your CROA/FCRA disclaimers on the hosting page.

© 2025 Credit Solutions.
