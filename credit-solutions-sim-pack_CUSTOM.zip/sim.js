// Credit Solutions Simulators — uses model.config.json
(function(){
  // Read config
  const cfg = JSON.parse(document.getElementById('credit-model').textContent);

  // ---------- Helpers
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  const usd = n => `$${Number(n).toLocaleString()}`;

  const bandFor = (score) =>
    cfg.scoreBands.find(b => score >= b.min && score <= b.max) || cfg.scoreBands[0];

  // ---------- DTI Calculator
  (function(){
    const debt = document.getElementById('debt');
    const debtNum = document.getElementById('debtNum');
    const income = document.getElementById('income');
    const incomeNum = document.getElementById('incomeNum');
    const out = document.getElementById('dtiOut');
    const bar = document.getElementById('dtiBar');
    const note = document.getElementById('dtiNote');

    if(!debt) return;

    debt.value = 1200; debtNum.value = 1200;
    income.value = 5000; incomeNum.value = 5000;

    const sync = (a,b) => a.addEventListener('input', ()=>{ b.value=a.value; render(); });
    sync(debt, debtNum); sync(debtNum, debt);
    sync(income, incomeNum); sync(incomeNum, income);

    function render(){
      const d = Math.max(0, Number(debt.value));
      const i = Math.max(0.01, Number(income.value));
      const dti = Math.round((d/i)*100);
      out.textContent = dti + '%';
      bar.style.width = Math.min(100, dti) + '%';

      if(dti <= cfg.dtiThresholds.ok){
        note.textContent = 'DTI looks healthy for most lenders.';
      } else if (dti <= cfg.dtiThresholds.warn){
        note.textContent = 'Borderline — some lenders may approve with conditions.';
      } else {
        note.textContent = 'High DTI — consider reducing debt or increasing income.';
      }
    }
    render();
  })();

  // ---------- Score Simulator
  (function(){
    const util = document.getElementById('util');
    const utilNum = document.getElementById('utilNum');
    const onTime = document.getElementById('onTime');
    const onTimeNum = document.getElementById('onTimeNum');
    const age = document.getElementById('age');
    const ageNum = document.getElementById('ageNum');
    const inq = document.getElementById('inq');
    const inqNum = document.getElementById('inqNum');
    const der = document.getElementById('derogsS');
    const derNum = document.getElementById('derogsSNum');
    const out = document.getElementById('scoreOut');
    const note = document.getElementById('scoreNote');
    const bandTag = document.getElementById('scoreBandTag');

    if(!util) return;

    util.value = 30; utilNum.value = 30;
    onTime.value = 95; onTimeNum.value = 95;
    age.value = 5; ageNum.value = 5;
    inq.value = 1; inqNum.value = 1;
    der.value = 2; derNum.value = 2;

    const sync = (a,b) => a.addEventListener('input', ()=>{ b.value=a.value; render(); });
    [ [util,utilNum], [onTime,onTimeNum], [age,ageNum], [inq,inqNum], [der,derNum] ].forEach(([a,b])=>{
      sync(a,b); sync(b,a);
    });

    function simulate(){
      const weights = cfg.scoreModelWeights;
      let score = cfg.baseScore;

      // Utilization: penalty above 10% target
      const utilOver = Math.max(0, Number(util.value) - 10);
      score += utilOver * weights.utilization;

      // On-time: credit above 80%
      const otpOver = Math.max(0, Number(onTime.value) - 80);
      score += otpOver * weights.onTimePct;

      // Age: credit above 1 year
      const ageOver = Math.max(0, Number(age.value) - 1);
      score += ageOver * weights.avgAgeYears;

      // Inquiries & Derogatories
      score += Number(inq.value) * weights.inquiries;
      score += Number(der.value) * weights.derogatories;

      return clamp(Math.round(score), cfg.scoreBounds.min, cfg.scoreBounds.max);
    }

    function render(){
      const s = simulate();
      out.textContent = s;
      const b = bandFor(s);
      bandTag.textContent = `${b.label} • ${s}`;
      note.textContent = `Adjust inputs to see potential direction of change. This is a teaching tool, not a FICO model.`;
    }
    render();
  })();

  // ---------- Pricing Marker
  (function(){
    const score = document.getElementById('score');
    const scoreNum = document.getElementById('scoreNum');
    const der = document.getElementById('derogs');
    const derNum = document.getElementById('derogsNum');
    const speed = document.getElementById('speed');
    const addonIdt = document.getElementById('addonIdt');
    const addonEdu = document.getElementById('addonEdu');

    const outMonthly = document.getElementById('outMonthly');
    const outSetup = document.getElementById('outSetup');
    const monthlyClamp = document.getElementById('monthlyClamp');
    const scaleLegend = document.getElementById('scaleLegend');

    const bandTag = document.getElementById('bandTag');
    const pin = document.getElementById('pin');
    const tag = document.getElementById('tag');

    if(!score) return;

    // defaults
    score.value = 620; scoreNum.value = 620;
    der.value = 4; derNum.value = 4;

    const sync = (a,b) => a.addEventListener('input', ()=>{ b.value=a.value; render(); });
    sync(score, scoreNum); sync(scoreNum, score);
    sync(der, derNum); sync(derNum, der);

    speed.addEventListener('change', render);
    addonIdt.addEventListener('change', render);
    addonEdu.addEventListener('change', render);

    document.getElementById('btnReset').addEventListener('click', ()=>{
      score.value = 620; scoreNum.value = 620;
      der.value = 4; derNum.value = 4;
      speed.value = 'standard';
      addonIdt.checked = false; addonEdu.checked = false;
      render();
    });

    document.getElementById('btnCopy').addEventListener('click', ()=>{
      const st = current();
      const q = compute(st);
      const txt = `Credit Solutions Quote
Score: ${st.score} (${q.band.label})
Derogatories: ${st.der}
Speed: ${st.rush ? 'Rush' : 'Standard'}
Monthly: ${usd(q.monthly)}${st.addonEdu ? ' + Credit Education' : ''}
Setup/Audit: ${usd(q.setup)}${st.addonIdt ? ' + ID Theft Packet' : ''}
(No guarantees. Estimates only.)`;
      navigator.clipboard.writeText(txt).then(()=>{
        const btn = document.getElementById('btnCopy');
        btn.textContent = 'Copied!';
        setTimeout(()=> btn.textContent='Copy Quote', 1200);
      });
    });

    function current(){
      return {
        score: Number(score.value),
        der: Number(der.value),
        rush: speed.value === 'rush',
        addonIdt: addonIdt.checked,
        addonEdu: addonEdu.checked
      };
    }

    function compute({score, der, rush, addonIdt, addonEdu}){
      const band = bandFor(score);
      const clampMin = cfg.clampMonthly.min;
      const clampMax = cfg.clampMonthly.max;

      let monthly = band.monthlyBase + (der * cfg.monthlyPerDerogatory);
      let setup   = cfg.setupFee.base + (der * cfg.setupFee.perDerogatory);

      if(rush){
        monthly *= 1 + (cfg.rushUpliftPct/100);
        setup   *= 1 + (cfg.rushUpliftPct/100);
      }

      if(addonEdu) monthly += cfg.addOns.creditEducation;
      if(addonIdt) setup   += cfg.addOns.idTheftPacket;

      monthly = clamp(Math.round(monthly), clampMin, clampMax);
      setup   = Math.round(setup);

      return {monthly, setup, band, clampMin, clampMax};
    }

    function render(){
      const st = current();
      const q = compute(st);

      outMonthly.textContent = usd(q.monthly);
      outSetup.textContent = usd(q.setup);
      bandTag.textContent = `${q.band.label} • ${st.score}`;
      monthlyClamp.textContent = `Clamped between ${usd(q.clampMin)} and ${usd(q.clampMax)}`;
      scaleLegend.textContent = `Min ${usd(q.clampMin)} · Max ${usd(q.clampMax)}`;

      // marker position on the scale
      const pct = (q.monthly - q.clampMin) / (q.clampMax - q.clampMin);
      const x = Math.round(pct * 100);
      pin.style.left = x + '%';
      tag.style.left = x + '%';
      tag.textContent = usd(q.monthly);
    }
    render();
  })();

  // expose a global helper for embedding all quickly
  window.CreditSolutions = {
    mountAll(){ /* this demo autoloads; kept for API compatibility */ }
  };
})();
